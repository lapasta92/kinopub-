#!/usr/bin/python
from resources.lib.main import plugin


if __name__ == "__main__":
    plugin.run()
